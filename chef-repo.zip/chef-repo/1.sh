ssl check
