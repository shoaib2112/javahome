#
# Cookbook:: jdk
# Recipe:: default
#
# Copyright:: 2017, The Author

execute 'oracle_jdk' do
   command ' sudo yum install java-1.7.0-openjdk -y'
end
