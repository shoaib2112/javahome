#
# Cookbook Name:: hello-world
# Recipe:: default
#
# Copyright 2017, YOUR_COMPANY_NAME
#
# All rights reserved - Do Not Redistribute
#

execute ' sample programme'  do
   command "echo  lets achieve your target"
end
