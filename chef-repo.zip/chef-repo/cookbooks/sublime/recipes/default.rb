#
# Cookbook Name:: sublime
# Recipe:: default
#
# Copyright 2017, YOUR_COMPANY_NAME
#
# All rights reserved - Do Not Redistribute
#
if node[:sublime][:version].empty?

 bash 'install_sublime' do
  user 'root'
  cwd '/tmp'
  code <<-EOH
  wget https://download.sublimetext.com/sublime_text_3_build_3126_x64.tar.bz2
   tar -jxf Sublime*.tar.bz2
  cd Sublime*
   EOH
node.set[:sublime][:version]='3126'
end

else
   if node.default[:sublime][:version]=='2.0.2'
  bash 'install_sublime' do
  user 'root'
  cwd '/tmp'
  code <<-EOH
  rm -rf Sublime #{node[:sublime][:version]}x64.tar.bz2
  rmdir -rf Sublime #{node[:sublime][:version]}
  wget https://download.sublimetext.com/sublime_text_3_build_3126_x64.tar.bz2
   tar -jxf Sublime*.tar.bz2
  cd Sublime*

   EOH
    node.set[:sublime][:version]='3126'
end
end

end
