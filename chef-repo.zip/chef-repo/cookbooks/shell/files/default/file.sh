
#!/bin/bash
echo " hello world"
touch file32
