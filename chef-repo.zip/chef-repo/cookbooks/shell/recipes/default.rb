#
# Cookbook Name:: shell
# Recipe:: default
#
# Copyright 2017, YOUR_COMPANY_NAME
#
# All rights reserved - Do Not Redistribute
#
cookbook_file "/tmp/file.sh" do
  source "file.sh"
  mode 0777
end

execute "shell " do
  command "sh /tmp/file.sh"
end
