#
# Cookbook Name:: oraclejdk
# Recipe:: default
#
# Copyright 2017, YOUR_COMPANY_NAME
#
# All rights reserved - Do Not Redistribute
#


execute 'wget command' do
    command 'sudo wget http://download.oracle.com/otn-pub/java/jdk/8u60-b27/jdk-8u60-linux-x64.rpm'
end

execute 'wget command' do
    command 'rpm -ivh jdk-8u60-linux-x64.rpm'
end


node.default['java_home'] = "/usr/java/jdk1.8.0_144"

magic_shell_environment 'JAVA_HOME' do
    action :remove
end

magic_shell_environment 'JAVA_HOME' do
    value node['java_home']
end


magic_shell_environment 'PATH' do
    value node['java_home']  + '/bin'  + ":" +
          node['gradle_home'] + '/bin' +
          ":$PATH"
end
