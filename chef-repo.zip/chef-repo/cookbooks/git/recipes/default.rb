#
# Cookbook:: git
# Recipe:: default
#
# Copyright:: 2017, The Authors, All Rights Reserved.
#file "/tmp/test.txt" do
#  content 'This file was created by Chef!'
#end
  execute 'install git' do
    command " sudo yum install git -y"
  end
