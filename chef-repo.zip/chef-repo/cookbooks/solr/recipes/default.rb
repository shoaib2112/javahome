#
# Cookbook Name:: solr
# Recipe:: default
#
# Copyright 2017, YOUR_COMPANY_NAME
#
# All rights reserved - Do Not Redistribute
#
directory '/home/ec2-user/solr' do
  owner 'root'
  group 'root'
  mode '0755'
  action :create
end

bash "solr_installation" do
 user 'root'
 cwd '/home/ec2-user/solr'
 code <<-EOH
  wget http://archive.apache.org/dist/lucene/solr/6.3.0/solr-6.3.0.tgz
  tar xzf solr-6.3.0.tgz solr-6.3.0/bin/install_solr_service.sh --strip-components=2
   bash ./install_solr_service.sh solr-6.3.0.tgz
   service solr start
   service solar stop
   service solr restart
   firewall-cmd --zone=public --add-port=8983/tcp --permanent
   firewall-cmd --reload
  EOH
end
