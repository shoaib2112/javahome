#
# Cookbook Name:: saty
# Recipe:: default
#
# Copyright 2017, YOUR_COMPANY_NAME
#
# All rights reserved - Do Not Redistribute
#
# Create a group named tomcat
group 'tomcat'

# Create a user named tomcat
user 'tomcat' do
    manage_home false
    shell '/bin/nologin'
    group 'tomcat'
    home '/opt/tomcat'
end

# Download tar file
remote_file 'apache-tomcat-8.5.20.tar.gz' do
    source 'http://apache.mirrors.tds.net/tomcat/tomcat-8/v8.5.20/bin/apache-tomcat-8.5.20.tar.gz'
end

# Create /opt/tomcat directory
directory '/opt/tomcat' do
    group 'tomcat'
    action :create
end

# Untar the zip
execute 'tar xvf apache-tomcat-8.5.20.tar.gz -C /opt/tomcat --strip-components=1'

# Make tomcat user the owner of the directory
execute 'chown -R tomcat /opt/tomcat'

# Create a service from the template
template '/etc/systemd/system/tomcat.service' do
    source 'tomcat.service.erb'
end

execute 'systemctl daemon-reload'

service 'tomcat' do
    action [:start, :enable]
end

# Download jenkins war file
remote_file 'jenkins.war' do
    source 'http://mirrors.jenkins.io/war-stable/latest/jenkins.war'
end

# Deploy jenkins war to Tomcat
execute 'cp jenkins.war /opt/tomcat/webapps'
