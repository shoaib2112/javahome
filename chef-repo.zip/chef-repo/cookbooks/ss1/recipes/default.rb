#
# Cookbook Name:: ss1
# Recipe:: default
#
# Copyright 2017, YOUR_COMPANY_NAME
#
# All rights reserved - Do Not Redistribute
#
execute ' install jdk' do
  command " sudo yum install java-1.7.0-openjdk-devel "
end
