#
# Cookbook Name:: solr1
# Recipe:: default
#
# Copyright 2017, YOUR_COMPANY_NAME
#tar xzf solr-6.3.0.tgz solr-6.3.0/bin/install_solr_service.sh --strip-components=2
# All rights reserved - Do Not Redistribute
#

directory '/home/ec2-user/solr' do
  owner 'root'
  group 'root'
  mode '0755'
  action :create
end

remote_file '/home/ec2-user/solr/solr-6.3.0.tgz'do
  owner'root'
  source 'http://archive.apache.org/dist/lucene/solr/6.3.0/solr-6.3.0.tgz'
end

execute 'extract the tar'do
 cwd 'home/ec2-user/solr'
 command 'tar xzf solr-6.3.0.tgz solr-6.3.0/bin/install_solr_service.sh --strip-components=2'
end

bash "solr_installation" do
 user 'root'
 cwd '/home/ec2-user/solr'
 code <<-EOH
sudo bash ./install_solr_service.sh solr-6.3.0.tgz
sudo firewall-cmd --zone=public --add-port=8983/tcp --permanent
sudo firewall-cmd --reload
sudo service solr restart
EOH
end
