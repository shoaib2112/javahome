#
# Cookbook Name:: solr6
# Recipe:: default
#
# Copyright 2017, YOUR_COMPANY_NAME
#
# All rights reserved - Do Not Redistribute
#
directory '/home/ec2-user/solr' do
  owner 'root'
  group 'root'
  mode '0755'
  action :create
end

remote_file '/home/ec2-user/solr/solr-6.6.0.tgz'do
  owner'root'
  source 'http://archive.apache.org/dist/lucene/solr/6.6.0/solr-6.6.0.tgz'
end

execute 'extract the tar'do
 cwd 'home/ec2-user/solr'
 command 'tar xzf solr-6.6.0.tgz solr-6.6.0/bin/install_solr_service.sh --strip-components=2'
end

bash "solr_installation" do
 user 'root'
 cwd '/home/ec2-user/solr'
 code <<-EOH
bash ./install_solr_service.sh solr-6.6.0.tgz
firewall-cmd --zone=public --add-port=8983/tcp --permanent
firewall-cmd --reload
service solr restart
EOH
end
